import os

# Auto-configure environment variables for Google Cloud Shell restarts
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "1"
if "GOOGLE_CLOUD_PROJECT" not in os.environ and "GCP_PROJECT" not in os.environ:
    os.environ["GOOGLE_CLOUD_PROJECT"] = "prj-ryan-mgmt-tools"
if "GOOGLE_CLOUD_LOCATION" not in os.environ:
    os.environ["GOOGLE_CLOUD_LOCATION"] = "us-central1"

import uvicorn
from fastapi.responses import FileResponse
from google.adk.cli.fast_api import get_fast_api_app

# Get current directory
current_dir = os.path.dirname(os.path.abspath(__file__))
agents_dir = os.path.join(current_dir, "live_avatar_agent")

print(f"Loading ADK agents from: {current_dir}")

# Create the standard ADK FastAPI app instance
app = get_fast_api_app(
    agents_dir=current_dir,
    session_service_uri="sqlite+aiosqlite:///sessions.db",
    allow_origins=["*"],
    web=True
)

# Serve avatar_client.html directly from the ADK server!
@app.get("/client")
async def get_client():
    client_path = os.path.join(agents_dir, "avatar_client.html")
    if os.path.exists(client_path):
        return FileResponse(client_path)
    return {"error": f"avatar_client.html not found at {client_path}"}

if __name__ == "__main__":
    print("\n" + "="*80)
    print(" CUSTOM ADK WEB SERVER STARTED SUCCESSFULLY")
    print(" Since you are running in GCP Cloud Shell, you can access the client directly:")
    print(" 1. Preview port 8000 in your Cloud Shell.")
    print(" 2. Append '/client' to the URL.")
    print(" This guarantees same-origin access with 0 browser cookie blocks!")
    print("="*80 + "\n")
    uvicorn.run(app, host="0.0.0.0", port=8000)
