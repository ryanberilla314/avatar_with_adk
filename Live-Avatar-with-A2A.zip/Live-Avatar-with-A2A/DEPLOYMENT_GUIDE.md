# NRG Billing Assistant: Rebranding & Deployment Guide

This guide provides step-by-step instructions to replicate or redeploy the **NRG Billing Assistant (Sky)**. It details the architecture, rebranding updates, and integration of the remote **A2A Agent Card** running on Vertex AI Agent Engine.

---

## 1. Architectural Overview

The application consists of three main components:

```mermaid
graph TD
    A[Client Web UI: avatar_client.html] <-->|WebSockets / Live Modality| B[Uvicorn Local ADK Server: run_server.py / agent.py]
    B <-->|REST API :streamQuery| C[Vertex AI Agent Engine: Reasoning Engine]
    C <-->|SQL Queries| D[(BigQuery Dataset)]
```

1. **Frontend Client UI (`avatar_client.html`)**: A web page that captures audio and video from the user, establishes a WebSocket connection to the local ADK server, and plays back the avatar's real-time responsive stream.
2. **Local ADK Server (`run_server.py` & `agent.py`)**: A Python-based ASGI application utilizing the Google Agent Development Kit (ADK). It orchestrates session configuration, manages the system prompt, registers the `lookup_account` tool, and serves the client.
3. **Remote Customer Account Agent (Vertex AI Reasoning Engine)**: A cloud-deployed agent holding database querying tools. It is accessed securely using Application Default Credentials (ADC) via HTTP streaming POST requests.

---

## 2. Prerequisites & Environment Setup

The following prerequisites must be met by any developer running this project:

### Python Dependencies
Install the required packages. Ensure `google-adk` is equipped with A2A extensions:
```bash
pip install "google-adk[a2a]" google-genai requests google-auth
```

### Google Cloud Authentication
To query the remote reasoning engine successfully, the running terminal session must be authenticated to Google Cloud with Application Default Credentials:
```bash
gcloud auth login
gcloud auth application-default login
```

---

## 3. Configuration & Auto-Environment

To make the application robust against Cloud Shell restarts and session cleanups, environment variables are dynamically initialized at the top of the backend scripts (`run_server.py` and `live_avatar_agent/agent.py`):

```python
import os

# Instruct the GenAI client to leverage Vertex AI endpoints
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "1"

# Automatically fallback to the designated project and region if unset
if "GOOGLE_CLOUD_PROJECT" not in os.environ and "GCP_PROJECT" not in os.environ:
    os.environ["GOOGLE_CLOUD_PROJECT"] = "prj-ryan-mgmt-tools"
if "GOOGLE_CLOUD_LOCATION" not in os.environ:
    os.environ["GOOGLE_CLOUD_LOCATION"] = "us-central1"
```

---

## 4. Rebranding Customizations

### System Prompt Identity (`live_avatar_agent/agent.py`)
Rebrand the system roles and instructions inside the `PROMPT_DEV` string:
- **Assistant Name**: "Sky"
- **Company Name**: "NRG"
- **Context/Behavior**: Instruct the agent to capture a **5-digit numeric Account ID** and run the `lookup_account` tool to retrieve billing summaries. Keep guidelines brief and conversational for real-time vocal output.

### Client UI Customization (`live_avatar_agent/avatar_client.html`)
- **Branding**: Change the side-navigation text headers from "Citi Wealth Live" to "nrg Billing Live".
- **Color Aesthetics**: Replace the primary colors with a warm energy theme using CSS classes:
  ```css
  .nrg-logo {
      font-size: 24px;
      font-weight: 800;
      letter-spacing: -0.5px;
      background: linear-gradient(135deg, #FF5722 0%, #FF2222 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 2px;
  }
  ```

---

## 5. Connecting to the Remote Agent Card

The local `lookup_account` tool communicates with the remote Agent Card deployed on Vertex AI Agent Engine.

### Endpoint Setup
- **Streaming Endpoint URL**: `https://<location>-aiplatform.googleapis.com/v1/projects/<project-id>/locations/<location>/reasoningEngines/<engine-id>:streamQuery`
- **Remote Resource**: `projects/419844573156/locations/us-central1/reasoningEngines/6766173005740507136`

### Crucial REST Payload Schema (Fixing 400 Bad Request)
The REST API expects snake_case (`"class_method"`) to identify which method to run inside the deployed `AdkApp`. Using camelCase (`"classMethod"`) will cause the request to fail with a `400 Bad Request` or fall back to the non-existent `"run"` method.

```python
payload = {
    "input": {
        "user_id": "web_avatar_user",
        "message": f"Retrieve information for account number {account_id}"
    },
    "class_method": "async_stream_query"  # MUST be snake_case!
}
```

### Non-blocking Stream Processing
Read chunked Server-Sent Events (SSE) data asynchronously in a background thread to prevent blocking Uvicorn's ASGI server:

```python
import asyncio
import requests
import json

def _query_agent():
    # ... Get credentials and make streaming POST request ...
    res = requests.post(url, json=payload, headers=headers, stream=True)
    res.raise_for_status()
    
    full_text = []
    for line in res.iter_lines():
        if line:
            decoded_line = line.decode('utf-8').strip()
            if decoded_line.startswith("data:"):
                decoded_line = decoded_line[5:].strip()
            try:
                data = json.loads(decoded_line)
                # Parse output chunks from the ADK streaming layout
                if "content" in data:
                    for part in data["content"]["parts"]:
                        if "text" in part:
                            full_text.append(part["text"])
            except Exception:
                pass
    return "".join(full_text)

# Offload the synchronous streaming download to a thread pool
response = await asyncio.to_thread(_query_agent)
```

---

## 6. Verification Steps for Redeployment

To test and confirm that a new deployment works seamlessly:

1. **Start the Web Server**:
   ```bash
   python3 run_server.py
   ```
2. **Access the Preview UI**:
   Open a browser to the web server's address and append `/client` to access the page (e.g. `http://localhost:8000/client`).
3. **Trigger the Tool**:
   Greet the avatar and request an account details lookup:
   > "Hi Sky, can you pull up account number 10022?"
4. **Inspect Terminal Stream Output**:
   Verify in your console that your stream lines are successfully retrieved and mapped:
   ```text
   [TOOL CALL] lookup_account triggered with account_id: 10022
   [TOOL CALL] Getting Application Default Credentials...
   [TOOL CALL] Querying Streaming REST API: https://us-central1-aiplatform.googleapis.com/...
   [STREAM LINE]: data: {"content": {"parts": [{"text": "Hello! Checking record..."}]}}
   [TOOL RESPONSE] Final combined output: ...
   ```
