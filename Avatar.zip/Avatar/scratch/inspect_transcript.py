import json
import os

def main():
    prev_conversation_id = "a458dbc9-7004-40f7-b460-bd32c3ea12db"
    transcript_path = os.path.join(
        "C:\\Users\\ryanberilla\\.gemini\\antigravity\\brain",
        prev_conversation_id,
        ".system_generated\\logs\\transcript_full.jsonl"
    )
    
    print(f"Inspecting file writes in: {transcript_path}")
    
    with open(transcript_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                step_index = data.get("step_index")
                tool_calls = data.get("tool_calls", [])
                
                # If there are tool calls, print their details
                for tc in tool_calls:
                    name = tc.get("name")
                    args = tc.get("args", {})
                    if name in ["write_to_file", "replace_file_content", "multi_replace_file_content"]:
                        target_file = args.get("TargetFile")
                        print(f"Step {step_index}: Tool: {name}, File: {target_file}")
            except Exception as e:
                pass

if __name__ == "__main__":
    main()
