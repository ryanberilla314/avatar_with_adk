import json
import os

def main():
    prev_conversation_id = "a458dbc9-7004-40f7-b460-bd32c3ea12db"
    transcript_path = os.path.join(
        "C:\\Users\\ryanberilla\\.gemini\\antigravity\\brain",
        prev_conversation_id,
        ".system_generated\\logs\\transcript_full.jsonl"
    )
    
    target_steps = {
        82: "requirements.txt",
        124: "agent.py",
        126: "server.py",
        138: "Dockerfile",
        269: "deploy.sh"
    }
    
    print(f"Extracting files from: {transcript_path}")
    
    with open(transcript_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                step_index = data.get("step_index")
                if step_index in target_steps:
                    filename = target_steps[step_index]
                    tool_calls = data.get("tool_calls", [])
                    for tc in tool_calls:
                        name = tc.get("name")
                        args = tc.get("args", {})
                        content = args.get("CodeContent")
                        if content:
                            output_path = os.path.join("C:\\Users\\ryanberilla\\Avatar", filename)
                            with open(output_path, 'w', encoding='utf-8') as out_f:
                                out_f.write(content)
                            print(f"Extracted {filename} (Step {step_index}) to {output_path}")
            except Exception as e:
                print(f"Error parsing step: {e}")

if __name__ == "__main__":
    main()
