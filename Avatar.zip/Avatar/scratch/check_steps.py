import json
import os

def main():
    prev_conversation_id = "a458dbc9-7004-40f7-b460-bd32c3ea12db"
    transcript_path = os.path.join(
        "C:\\Users\\ryanberilla\\.gemini\\antigravity\\brain",
        prev_conversation_id,
        ".system_generated\\logs\\transcript_full.jsonl"
    )
    
    print(f"Inspecting step 12 and 14...")
    
    with open(transcript_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                step_index = data.get("step_index")
                if step_index in [12, 14]:
                    content = data.get("content", "")
                    print(f"Step {step_index}: content length: {len(content)}")
                    first_lines = content.split('\n')[:5]
                    print(f"First 5 lines of step {step_index}:")
                    for fl in first_lines:
                        print(f"  {fl}")
            except Exception as e:
                pass

if __name__ == "__main__":
    main()
