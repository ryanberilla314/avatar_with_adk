import json
import os
import re

def clean_lines(text):
    lines = text.split('\n')
    cleaned_lines = []
    
    for line in lines:
        # Check if line contains any of the headers/footers to skip
        if any(h in line for h in [
            "The following code has been modified",
            "Created At:",
            "Completed At:",
            "File Path:",
            "Total Lines:",
            "Total Bytes:",
            "Showing lines",
            "The above content"
        ]):
            continue
            
        match = re.match(r'^\s*(\d+):\s(.*)$', line)
        if match:
            # We matched a line number! Extract the original line content.
            cleaned_lines.append(match.group(2))
        else:
            cleaned_lines.append(line)
            
    return '\n'.join(cleaned_lines)

def main():
    prev_conversation_id = "a458dbc9-7004-40f7-b460-bd32c3ea12db"
    transcript_path = os.path.join(
        "C:\\Users\\ryanberilla\\.gemini\\antigravity\\brain",
        prev_conversation_id,
        ".system_generated\\logs\\transcript_full.jsonl"
    )
    
    output_dir = "C:\\Users\\ryanberilla\\Avatar"
    output_html_path = os.path.join(output_dir, "avatar_client.html")
    
    part1 = None
    part2 = None
    
    with open(transcript_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                step_index = data.get("step_index")
                if step_index == 12:
                    part1 = clean_lines(data.get("content", ""))
                elif step_index == 14:
                    part2 = clean_lines(data.get("content", ""))
            except Exception:
                pass
                
    if part1 and part2:
        full_html = part1.strip() + "\n" + part2.strip()
        
        # Do the dynamic URL replacement
        target_str = "    const httpUrl = `http://localhost:8000/apps/${appName}/users/${userId}/sessions`;\n    const websocketUrl = `ws://localhost:8000/run_live?user_id=${userId}&session_id=${sessionId}&app_name=${appName}&save_live_blob=true`;"
        
        replacement_str = """    const protocol = window.location.protocol;
    const wsProtocol = protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;

    const httpUrl = `${protocol}//${host}/apps/${appName}/users/${userId}/sessions`;
    const websocketUrl = `${wsProtocol}//${host}/run_live?user_id=${userId}&session_id=${sessionId}&app_name=${appName}&save_live_blob=true`;"""
        
        # We need to make sure we match despite CRLF vs LF differences
        full_html_normalized = full_html.replace('\r\n', '\n')
        target_str_normalized = target_str.replace('\r\n', '\n')
        
        if target_str_normalized in full_html_normalized:
            full_html_normalized = full_html_normalized.replace(target_str_normalized, replacement_str)
            print("Successfully replaced hardcoded URLs with dynamic URLs!")
        else:
            print("WARNING: Could not find the hardcoded URLs to replace exactly!")
            # Let's do a fallback replacement using regex to find httpUrl and websocketUrl
            full_html_normalized = re.sub(
                r'const httpUrl = `http://localhost:8000[^`]*`;\s*const websocketUrl = `ws://localhost:8000[^`]*`;',
                replacement_str,
                full_html_normalized
            )
            print("Performed regex-based URL replacement!")
            
        with open(output_html_path, 'w', encoding='utf-8', newline='\n') as f:
            f.write(full_html_normalized)
            
        print(f"Successfully reconstructed and wrote {output_html_path}")
    else:
        print("Error: Could not find both parts of avatar_client.html in the logs!")

if __name__ == "__main__":
    main()
