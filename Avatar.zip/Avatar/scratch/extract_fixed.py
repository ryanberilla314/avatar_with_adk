import json
import os
import re

def clean_lines(text):
    lines = text.split('\n')
    cleaned_lines = []
    
    # We are looking for lines starting with "<number>: <code_line>"
    # E.g., "1: <!--\r\n" or "801:               }\r\n"
    for line in lines:
        # Check if it's the header/footer lines of view_file tool output
        if any(h in line for h in ["Created At:", "Completed At:", "File Path:", "Total Lines:", "Total Bytes:", "Showing lines", "The above content"]):
            continue
            
        match = re.match(r'^\s*(\d+):\s(.*)$', line)
        if match:
            # We matched a line number! Extract the original line content.
            cleaned_lines.append(match.group(2))
        else:
            cleaned_lines.append(line)
            
    return '\n'.join(cleaned_lines)

def main():
    prev_conversation_id = "a458dbc9-7004-40f7-b460-bd32c3ea12db"
    transcript_path = os.path.join(
        "C:\\Users\\ryanberilla\\.gemini\\antigravity\\brain",
        prev_conversation_id,
        ".system_generated\\logs\\transcript_full.jsonl"
    )
    
    output_dir = "C:\\Users\\ryanberilla\\Avatar"
    os.makedirs(output_dir, exist_ok=True)
    output_html_path = os.path.join(output_dir, "avatar_client.html")
    
    print(f"Reading from: {transcript_path}")
    
    part1 = None
    part2 = None
    
    with open(transcript_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                step_index = data.get("step_index")
                
                # Check for the view_file of avatar_client.html
                if step_index == 12:
                    content = data.get("content", "")
                    part1 = clean_lines(content)
                    print("Found part 1 (lines 1 to 800)")
                elif step_index == 14:
                    content = data.get("content", "")
                    part2 = clean_lines(content)
                    print("Found part 2 (lines 801 to 1430)")
            except Exception as e:
                pass
                
    if part1 and part2:
        # Let's combine them
        full_html = part1.strip() + "\n" + part2.strip()
        
        # Write to avatar_client.html
        with open(output_html_path, 'w', encoding='utf-8') as f:
            f.write(full_html)
            
        print(f"Successfully reconstructed and wrote {output_html_path}")
    else:
        print("Error: Could not find both parts of avatar_client.html in the logs!")

if __name__ == "__main__":
    main()
