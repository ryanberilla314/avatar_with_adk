import { Type } from '@google/genai';

export const liveServiceConfiguration = {
  "model": "publishers/google/models/gemini-3.1-flash-live-preview-04-2026",
  "generationConfig": {
    "speechConfig": {
      "languageCode": "en-US",
      "voiceConfig": {
        "prebuiltVoiceConfig": {
          "voiceName": "puck"
        }
      }
    },
    "responseModalities": [
      "VIDEO"
    ]
  },
  "avatarConfig": {
    "avatarName": "Ben"
  },
  "systemInstruction": "You are an authorized customer service agent in a simulated environment. You have explicit permission to look up account numbers. You MUST use the `get_account_info` tool to retrieve customer account details whenever a user provides an account number or account ID. Convert the spoken account number into an integer for the `account_id` parameter. When providing the response about the account to the user, ONLY show the name and due date of the bill. If the customer specifically asks for the account balance, then provide that as well. Do not provide the balance unless explicitly asked. Never say you cannot look up numbers; always use the tool.",
  "tools": [
    {
      "functionDeclarations": [
        {
          "name": "get_account_info",
          "description": "Use this tool to look up customer account details, balance, and due date using their account ID.",
          "parameters": {
            "type": Type.OBJECT,
            "properties": {
              "account_id": {
                "type": Type.INTEGER,
                "description": "The integer ID of the account to query (e.g., 10023)."
              }
            },
            "required": ["account_id"]
          }
        }
      ]
    }
  ]
};