import React, { useEffect, useRef } from 'react';
import { SessionError } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  errors: SessionError[];
}

export const ErrorPanel: React.FC<Props> = ({ isOpen, onClose, errors }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [errors, isOpen]);

  return (
    <div
      className={`h-full bg-white dark:bg-gray-900 border-l border-gray-200 dark:border-gray-800 flex flex-col flex-shrink-0 transition-all duration-300 ease-in-out overflow-hidden ${
        isOpen ? 'w-80 md:w-96 opacity-100' : 'w-0 opacity-0 border-transparent'
      }`}
    >
      <div className="w-80 md:w-96 h-full flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-red-50/50 dark:bg-red-900/20 backdrop-blur-sm">
          <h2 className="text-lg font-semibold text-red-800 dark:text-red-200 flex items-center gap-2">
            <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            Session Errors
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors"
            title="Close Panel"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Error List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3 font-mono text-xs" ref={scrollRef}>
          {errors.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 dark:text-gray-500 text-sm text-center px-4 gap-3">
              <svg className="w-12 h-12 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p>No session errors recorded.</p>
            </div>
          )}

          {errors.map((err) => (
            <div key={err.id} className="p-3 rounded-md border text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-900/30 break-words whitespace-pre-wrap shadow-sm">
              <div className="flex justify-between items-start mb-2 opacity-70 text-[10px] tracking-wider border-b border-red-200/50 dark:border-red-800/50 pb-1">
                <span className="uppercase font-bold">ERROR</span>
                <span>{err.timestamp.toLocaleTimeString()}</span>
              </div>
              <div className="font-semibold mb-1 text-sm">{err.message}</div>
              {err.details && (
                <div className="mt-2 p-2 bg-white/50 dark:bg-black/30 rounded text-[10px] overflow-x-auto">
                  {err.details}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};