export interface ChatMessage {
  id: string;
  role: 'user' | 'model' | 'system';
  text: string;
  isFinal: boolean;
}

export type VideoMode = 'none' | 'webcam' | 'screen';

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'log' | 'error' | 'warn' | 'info' | 'debug';
  message: string;
}

export interface SessionError {
  id: string;
  timestamp: Date;
  message: string;
  details?: string;
}