import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage } from '@google/genai';
import { liveServiceConfiguration } from '../resources/live_service_configuration';
import { decode, createBlob } from '../services/audioUtils';
import { createA2ASession, queryA2AAgent } from '../services/a2aService';
import { ChatMessage, SessionError } from '../types';

const LIVE_API_MODEL_NAME = 'gemini-live-2.5-flash-native-audio';

export const useLiveSession = (
  selectedAudioOutputId: string,
  isMuted: boolean,
  isVideoEnabled: boolean,
  webcamVideoRef: React.RefObject<HTMLVideoElement | null>
) => {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [isSetupComplete, setIsSetupComplete] = useState<boolean>(false);
  const [isWaitingForVideo, setIsWaitingForVideo] = useState<boolean>(false);
  const [hasVideo, setHasVideo] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionErrors, setSessionErrors] = useState<SessionError[]>([]);

  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [liveInput, setLiveInput] = useState<string>('');
  const [liveOutput, setLiveOutput] = useState<string>('');
  const [agentTalking, setAgentTalking] = useState<boolean>(false);

  const [debugStats, setDebugStats] = useState({
    buffered: 0,
    droppedFrames: 0,
    duration: 0,
    latency: 0,
  });

  const isSetupCompleteRef = useRef<boolean>(false);
  const agentTalkingRef = useRef<boolean>(false);
  const currentInputTextRef = useRef<string>('');
  const currentOutputTextRef = useRef<string>('');

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const outputNodeRef = useRef<GainNode | null>(null);
  const videoSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const videoAnalyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const frameIntervalRef = useRef<number | null>(null);

  // A2A Agent Refs
  const a2aSessionIdRef = useRef<string | null>(null);
  const a2aUserIdRef = useRef<string>(`user-${Math.random().toString(36).substring(7)}`);

  // Latency Tracking Refs
  const lastUserSpeechTimeRef = useRef<number>(0);
  const userHasSpokenForNextTurnRef = useRef<boolean>(false);
  const trackingAvatarAudioRef = useRef<boolean>(false);
  const avatarAudioStartPlayheadRef = useRef<number | null>(null);
  const avatarAudioStartPlayheadSystemTimeRef = useRef<number | null>(null);
  const latencyRef = useRef<number>(0);

  // Video Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mseRef = useRef<MediaSource | null>(null);
  const sourceBufferRef = useRef<SourceBuffer | null>(null);
  const videoQueueRef = useRef<ArrayBuffer[]>([]);
  const cachedInitSegmentRef = useRef<ArrayBuffer | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const videoErrorListenerAddedRef = useRef<boolean>(false);

  const handleError = useCallback((message: string, details?: any) => {
    console.error(`[LiveSession Error] ${message}`, details || '');
    setError(message);
    
    let detailsStr = undefined;
    if (details) {
      if (details instanceof Error) {
        detailsStr = `${details.name}: ${details.message}\n${details.stack || ''}`;
      } else if (typeof details === 'object') {
        try {
          detailsStr = JSON.stringify(details, null, 2);
        } catch (e) {
          detailsStr = String(details);
        }
      } else {
        detailsStr = String(details);
      }
    }

    setSessionErrors(prev => [...prev, {
      id: Math.random().toString(36).substring(2, 9) + Date.now(),
      timestamp: new Date(),
      message,
      details: detailsStr
    }]);
  }, []);

  useEffect(() => {
    agentTalkingRef.current = agentTalking;
  }, [agentTalking]);

  // Initialize Output AudioContext
  useEffect(() => {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    outputAudioContextRef.current = ctx;
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    outputNodeRef.current = gain;

    if (videoRef.current) {
      try {
        videoSourceRef.current = ctx.createMediaElementSource(videoRef.current);
        videoAnalyserRef.current = ctx.createAnalyser();
        videoAnalyserRef.current.fftSize = 2048;
        videoSourceRef.current.connect(videoAnalyserRef.current);
        videoAnalyserRef.current.connect(gain);
      } catch (e) {
        handleError("Failed to create media element source", e);
      }
    }

    return () => {
      ctx.close();
    };
  }, [handleError]);

  // Apply selected audio output device
  useEffect(() => {
    const applyAudioOutput = async () => {
      if (!selectedAudioOutputId) return;

      if (videoRef.current && typeof (videoRef.current as any).setSinkId === 'function') {
        try {
          await (videoRef.current as any).setSinkId(selectedAudioOutputId);
        } catch (e) {
          handleError("Failed to set video sink", e);
        }
      }

      if (outputAudioContextRef.current && typeof (outputAudioContextRef.current as any).setSinkId === 'function') {
        try {
          await (outputAudioContextRef.current as any).setSinkId(selectedAudioOutputId);
        } catch (e) {
          handleError("Failed to set audio context sink", e);
        }
      }
    };

    applyAudioOutput();
  }, [selectedAudioOutputId, isConnected, handleError]);

  // Apply mute state
  useEffect(() => {
    if (streamRef.current) {
      streamRef.current.getAudioTracks().forEach(track => {
        track.enabled = !isMuted;
      });
    }
  }, [isMuted]);

  // Video Streaming Effect
  useEffect(() => {
    if (isConnected && isVideoEnabled) {
      const canvasEl = document.createElement('canvas');
      const ctx = canvasEl.getContext('2d');

      frameIntervalRef.current = window.setInterval(() => {
        if (!isSetupCompleteRef.current) return; // Gate video sending until setup is complete
        if (!webcamVideoRef.current || !sessionPromiseRef.current) return;
        const videoEl = webcamVideoRef.current;

        if (videoEl.readyState >= 2 && videoEl.videoWidth > 0) {
          let width = videoEl.videoWidth;
          let height = videoEl.videoHeight;
          const maxDim = 768;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          canvasEl.width = width;
          canvasEl.height = height;
          ctx?.drawImage(videoEl, 0, 0, width, height);

          canvasEl.toBlob(
            (blob) => {
              if (blob) {
                const reader = new FileReader();
                reader.onloadend = () => {
                  const frame = (reader.result as string).split(',')[1];
                  if (sessionPromiseRef.current) {
                    sessionPromiseRef.current.then((session) => {
                      try {
                        session.sendRealtimeInput({
                          video: {
                            data: frame,
                            mimeType: 'image/jpeg'
                          }
                        });
                      } catch (e) {
                        handleError("Failed to send video frame", e);
                      }
                    }).catch(e => handleError("Promise rejection sending video frame", e));
                  }
                };
                reader.readAsDataURL(blob);
              }
            },
            'image/jpeg',
            0.8
          );
        }
      }, 1000);
    }

    return () => {
      if (frameIntervalRef.current) {
        window.clearInterval(frameIntervalRef.current);
        frameIntervalRef.current = null;
      }
    };
  }, [isConnected, isVideoEnabled, webcamVideoRef, handleError]);

  const initMediaSource = useCallback(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;
    if (!window.MediaSource) {
      handleError("MediaSource API not supported.");
      return;
    }
    if (mseRef.current) return;

    const mediaSource = new MediaSource();
    mseRef.current = mediaSource;
    videoElement.src = URL.createObjectURL(mediaSource);

    if (!videoErrorListenerAddedRef.current) {
      videoElement.addEventListener("error", (e) => {
        if (!mseRef.current) return;
        mseRef.current = null;
        sourceBufferRef.current = null;
        videoQueueRef.current = [];
        handleError("Video playback error.", e);
      });
      videoErrorListenerAddedRef.current = true;
    }

    mediaSource.addEventListener("sourceopen", () => {
      try {
        let sourceBuffer = sourceBufferRef.current;
        if (!sourceBuffer) {
          const type = 'video/mp4; codecs="avc1.42E01E, mp4a.40.2"';
          if (MediaSource.isTypeSupported(type)) {
            sourceBuffer = mediaSource.addSourceBuffer(type);
          } else {
            sourceBuffer = mediaSource.addSourceBuffer("video/mp4");
          }
          sourceBuffer.mode = "sequence";
          sourceBufferRef.current = sourceBuffer;

          const cachedInitSegment = cachedInitSegmentRef.current;
          if (cachedInitSegment && videoQueueRef.current[0] !== cachedInitSegment) {
            videoQueueRef.current.unshift(cachedInitSegment);
          }
        }

        const currentSourceBuffer = sourceBufferRef.current;
        if (!currentSourceBuffer) {
          return;
        }

        if (videoQueueRef.current.length > 0 && !currentSourceBuffer.updating) {
          const chunk = videoQueueRef.current.shift();
          if (chunk) {
            try {
              currentSourceBuffer.appendBuffer(chunk);
            } catch (e) {
              handleError("Error setting video stream", e);
            }
          }
        }

        currentSourceBuffer.addEventListener("updateend", () => {
          const sb = sourceBufferRef.current;
          const ms = mseRef.current;
          if (!sb || !ms) return;

          if (videoElement.paused) {
            videoElement.play().catch((e) => {
              handleError("Error playing video", e);
            });
          }

          if (ms.readyState === 'open' && videoElement.buffered.length > 0) {
            try {
              const end = videoElement.buffered.end(videoElement.buffered.length - 1);
              ms.setLiveSeekableRange(0, end);
            } catch (e) {
              // Ignore
            }
          }

          // --- Explicitly remove unneeded data from the buffer ---
          // We keep 5 seconds of history to prevent playback stalls, but aggressively remove older data.
          if (!sb.updating && videoElement.currentTime > 6) {
            try {
              if (videoElement.buffered.length > 0) {
                const start = videoElement.buffered.start(0);
                const endToRemove = videoElement.currentTime - 5;
                if (endToRemove > start) {
                  sb.remove(start, endToRemove);
                  return;
                }
              }
            } catch (e) {
              // Ignore
            }
          }

          if (videoQueueRef.current.length > 0 && !sb.updating) {
            const chunk = videoQueueRef.current.shift();
            if (chunk) {
              try {
                sb.appendBuffer(chunk);
              } catch (e) {
                handleError("Error setting video stream", e);
              }
            }
          }
        });
      } catch (e: any) {
        handleError('Failed to initialize video stream.', e);
      }
    });
  }, [handleError]);

  const monitoringLoop = useCallback(() => {
    if (videoRef.current) {
      const video = videoRef.current;

      // --- Latency Check ---
      // Check if we are tracking 3 seconds of audible video playback
      if (trackingAvatarAudioRef.current && videoAnalyserRef.current) {
        if (avatarAudioStartPlayheadRef.current === null) {
          const dataArray = new Float32Array(videoAnalyserRef.current.fftSize);
          videoAnalyserRef.current.getFloatTimeDomainData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i] * dataArray[i];
          }
          const rms = Math.sqrt(sum / dataArray.length);

          if (rms > 0.02) {
            avatarAudioStartPlayheadRef.current = video.currentTime;
            avatarAudioStartPlayheadSystemTimeRef.current = performance.now();
          }
        } else if (video.currentTime - avatarAudioStartPlayheadRef.current >= 3) {
          if (avatarAudioStartPlayheadSystemTimeRef.current !== null && lastUserSpeechTimeRef.current > 0) {
            latencyRef.current = avatarAudioStartPlayheadSystemTimeRef.current - lastUserSpeechTimeRef.current;
          }
          trackingAvatarAudioRef.current = false;
          avatarAudioStartPlayheadRef.current = null;
          avatarAudioStartPlayheadSystemTimeRef.current = null;
        }
      }

      // --- Adaptive buffer management based on agent talking state ---
      if (video.readyState >= 2 && !video.paused && video.buffered.length > 0) {
        const bufferedEnd = video.buffered.end(video.buffered.length - 1);
        const bufferAhead = bufferedEnd - video.currentTime;

        if (agentTalkingRef.current) {
          video.playbackRate = 1.0;
        } else {
          if (bufferAhead > 2.0) {
            video.currentTime = bufferedEnd - 0.05;
            video.playbackRate = 1.0;
          } else if (bufferAhead > 0.4) {
            video.playbackRate = Math.min(1.2, 1.0 + bufferAhead * 2);
          } else {
            video.playbackRate = 1.0;
          }
        }
      }

      // Update debug stats
      let buffered = 0;
      let duration = video.duration;

      if (video.buffered.length > 0) {
        const bufferedEnd = video.buffered.end(video.buffered.length - 1);
        buffered = bufferedEnd - video.currentTime;
        if (isNaN(duration) || !isFinite(duration)) {
          duration = bufferedEnd;
        }
      } else if (isNaN(duration) || !isFinite(duration)) {
        duration = 0;
      }

      let droppedFrames = 0;
      if (typeof (video as any).getVideoPlaybackQuality === 'function') {
        droppedFrames = (video as any).getVideoPlaybackQuality().droppedVideoFrames;
      }
      setDebugStats({
        buffered: Math.max(0, buffered),
        droppedFrames,
        duration: duration,
        latency: latencyRef.current,
      });
    }
    animationFrameRef.current = requestAnimationFrame(monitoringLoop);
  }, []);

  const disconnect = useCallback(() => {
    console.info('[Live API] Disconnecting...');
    setIsConnected(false);
    setIsConnecting(false);
    setIsSetupComplete(false);
    isSetupCompleteRef.current = false;
    setIsWaitingForVideo(false);
    setHasVideo(false);

    userHasSpokenForNextTurnRef.current = false;
    trackingAvatarAudioRef.current = false;
    avatarAudioStartPlayheadRef.current = null;
    avatarAudioStartPlayheadSystemTimeRef.current = null;
    latencyRef.current = 0;
    a2aSessionIdRef.current = null;
    
    setDebugStats({
      buffered: 0,
      droppedFrames: 0,
      duration: 0,
      latency: 0,
    });

    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => {
        try {
          session.close();
          console.info('[Live API] Session closed successfully.');
        } catch (e) {
          handleError("Failed to close session", e);
        }
      }).catch(e => handleError("Promise rejection closing session", e));
      sessionPromiseRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }

    if (mediaSourceRef.current) {
      mediaSourceRef.current.disconnect();
      mediaSourceRef.current = null;
    }

    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    videoQueueRef.current = [];
    cachedInitSegmentRef.current = null;
    if (mseRef.current && mseRef.current.readyState === 'open') {
      try {
        mseRef.current.endOfStream();
      } catch (e) { 
        handleError("Failed to end stream", e);
      }
    }
    if (videoRef.current) {
      videoRef.current.pause();
      if (videoRef.current.src && videoRef.current.src.startsWith('blob:')) {
        URL.revokeObjectURL(videoRef.current.src);
      }
      videoRef.current.removeAttribute('src');
      videoRef.current.load();
    }
    sourceBufferRef.current = null;
    mseRef.current = null;
  }, [handleError]);

  const connect = useCallback(async (deviceId: string) => {
    if (isConnected || isConnecting) return;

    console.info('[Live API] 🚀 Initializing connection...');
    setIsConnecting(true);
    setIsSetupComplete(false);
    isSetupCompleteRef.current = false;
    setIsWaitingForVideo(true);
    setError(null);
    setHasVideo(false);

    setChatHistory([]);
    setLiveInput('');
    setLiveOutput('');
    currentInputTextRef.current = '';
    currentOutputTextRef.current = '';

    userHasSpokenForNextTurnRef.current = false;
    trackingAvatarAudioRef.current = false;
    avatarAudioStartPlayheadRef.current = null;
    avatarAudioStartPlayheadSystemTimeRef.current = null;
    latencyRef.current = 0;

    try {
      // 🔐 Load standard access tokens or environment fallback.
      // Note: passing any non-empty string here satisfies the SDK's browser runtime check.
      const gcpAccessToken = 
        process.env.REACT_APP_GCP_ACCESS_TOKEN || 
        process.env.GCP_ACCESS_TOKEN || 
        process.env.REACT_APP_API_KEY || 
        process.env.API_KEY ||
        "PROJECT_DEFAULT";

      console.debug('[Live API] Initializing GoogleGenAI for Vertex AI...');
      // ⚠️ Fixed: Project-based auth is NOT supported in browser runtimes.
      // Therefore, do NOT provide 'project' or 'location' here. 
      const ai = new GoogleGenAI({
        vertexai: true,
        apiKey: gcpAccessToken
      });
      
      console.debug('[Live API] Requesting microphone access...');
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: deviceId ? { deviceId: { exact: deviceId } } : true
      });

      stream.getAudioTracks().forEach(track => track.enabled = !isMuted);
      streamRef.current = stream;

      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      inputAudioContextRef.current = inputAudioContext;

      if (outputAudioContextRef.current?.state === 'suspended') {
        await outputAudioContextRef.current.resume();
      }

      videoQueueRef.current = [];
      cachedInitSegmentRef.current = null;

      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      monitoringLoop();

      const startAudioInput = () => {
        if (scriptProcessorRef.current || !inputAudioContextRef.current || !streamRef.current) return;

        const source = inputAudioContextRef.current.createMediaStreamSource(streamRef.current);
        const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);

        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
          if (!isSetupCompleteRef.current) return; // Gate audio sending until setup is complete

          const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);

          let sum = 0;
          for (let i = 0; i < inputData.length; i++) {
            sum += inputData[i] * inputData[i];
          }
          const rms = Math.sqrt(sum / inputData.length);
          if (rms > 0.01) {
            lastUserSpeechTimeRef.current = performance.now();
            userHasSpokenForNextTurnRef.current = true;
          }

          const pcmBlob = createBlob(inputData);
          if (sessionPromiseRef.current) {
            sessionPromiseRef.current.then((session) => {
              session.sendRealtimeInput({ media: pcmBlob });
            }).catch(e => {
              // Suppress spammy audio errors, but log them to debug
              console.debug("Failed to send audio frame", e);
            });
          }
        };

        source.connect(scriptProcessor);
        scriptProcessor.connect(inputAudioContextRef.current.destination);

        mediaSourceRef.current = source;
        scriptProcessorRef.current = scriptProcessor;
        console.info('[Live API] 🎤 Audio input streaming started.');
      };

      // Format model name correctly for Vertex AI
      let modelName = (liveServiceConfiguration as any).model || LIVE_API_MODEL_NAME;
      if (modelName.startsWith('publishers/google/models/')) {
        modelName = modelName.replace('publishers/google/models/', '');
      }

      // Build config dynamically to avoid passing unsupported empty objects
      // Force enable transcriptions for debugging and UI display
      const liveConfig: any = {
        inputAudioTranscription: { model: "telephony" },
        outputAudioTranscription: { model: "telephony" }
      };
      
      if ((liveServiceConfiguration as any).systemInstruction) {
        liveConfig.systemInstruction = (liveServiceConfiguration as any).systemInstruction;
      }
      
      // Robust tool loading from direct or nested structure
      const toolsConfig = (liveServiceConfiguration as any).tools || (liveServiceConfiguration as any).generationConfig?.tools;
      if (toolsConfig) {
        liveConfig.tools = toolsConfig;
      }
      
      if ((liveServiceConfiguration as any).generationConfig?.responseModalities) {
        liveConfig.responseModalities = (liveServiceConfiguration as any).generationConfig.responseModalities;
      }
      if ((liveServiceConfiguration as any).generationConfig?.speechConfig) {
        liveConfig.speechConfig = (liveServiceConfiguration as any).generationConfig.speechConfig;
      }
      if ((liveServiceConfiguration as any).avatarConfig) {
        liveConfig.avatarConfig = (liveServiceConfiguration as any).avatarConfig;
      }

      console.info(`[Live API] 🔌 Connecting to model: ${modelName}`);
      console.info('[Live API] ⚙️ Configuration:', JSON.stringify(liveConfig, null, 2));

      const sessionPromise = ai.live.connect({
        model: modelName,
        callbacks: {
          onopen: () => {
            console.info('[Live API] ✅ Connection opened successfully.');
            setIsConnected(true);
            // Do not set isConnecting to false here, wait for setupComplete
            startAudioInput();
          },
          onmessage: async (message: LiveServerMessage) => {
            // Log raw message structure (excluding large base64 data)
            try {
              const safeMessage = JSON.parse(JSON.stringify(message, (key, value) => {
                if (key === 'data' && typeof value === 'string' && value.length > 100) {
                  return `[BASE64_DATA_LENGTH_${value.length}]`;
                }
                return value;
              }));
              
              // Only log if it's not just a pure audio/video chunk to avoid spam
              const isJustMedia = message.serverContent?.modelTurn?.parts?.every(p => p.inlineData) && !message.serverContent?.outputTranscription && !message.serverContent?.interrupted && !message.serverContent?.turnComplete;
              if (!isJustMedia) {
                console.debug('[Live API] 📩 Received Message:', JSON.stringify(safeMessage, null, 2));
              }
            } catch (e) {
              console.debug('[Live API] 📩 Received Message (unparseable)');
            }

            if (message.setupComplete) {
              console.info('[Live API] 🏁 Setup complete message received.');
              setIsSetupComplete(true);
              isSetupCompleteRef.current = true;
              setIsConnecting(false); // Setup is complete, no longer connecting
            }

            if (message.serverContent?.interrupted) {
              console.info('[Live API] 🛑 Server interrupted.');
            }

            if (message.serverContent?.turnComplete) {
              console.info('[Live API] 🔄 Turn complete.');
            }

            if (message.toolCall) {
              console.info(`[Live API] 🛠️ TOOL CALL RECEIVED:`, JSON.stringify(message.toolCall, null, 2));
              for (const fc of message.toolCall.functionCalls) {
                if (fc.name === 'get_account_info') {
                  const accountId = fc.args.account_id;
                  console.info(`[Live API] ⚙️ Executing get_account_info for account_id: ${accountId}`);
                  
                  // Add system message to chat history to show agent is working
                  setChatHistory(prev => [...prev, {
                    id: `system-${Date.now()}-start`,
                    role: 'system',
                    text: `Agent is looking up account details for: ${accountId}...`,
                    isFinal: true
                  }]);
                  
                  // Execute async operation without blocking the message loop
                  (async () => {
                    try {
                      if (!a2aSessionIdRef.current) {
                        console.info('[A2A] 🆕 Creating new A2A session...');
                        a2aSessionIdRef.current = await createA2ASession(a2aUserIdRef.current);
                        console.info(`[A2A] ✅ Session created: ${a2aSessionIdRef.current}`);
                      }
                      const queryMessage = `Get details for account id: ${accountId}`;
                      console.info(`[A2A] 🔍 Querying A2A Agent with message: "${queryMessage}"`);
                      const resultText = await queryA2AAgent(a2aUserIdRef.current, a2aSessionIdRef.current, queryMessage);
                      console.info(`[A2A] 🎯 Agent Response: ${resultText}`);
                      
                      setChatHistory(prev => [...prev, {
                        id: `system-${Date.now()}-success`,
                        role: 'system',
                        text: `Successfully retrieved account details.`,
                        isFinal: true
                      }]);

                      if (sessionPromiseRef.current) {
                        sessionPromiseRef.current.then((session) => {
                          const toolResponsePayload = {
                            functionResponses: [{
                              id: fc.id,
                              name: fc.name,
                              response: { result: resultText }
                            }]
                          };
                          console.info('[Live API] 📤 Sending tool response payload:', JSON.stringify(toolResponsePayload, null, 2));
                          session.sendToolResponse(toolResponsePayload);
                        }).catch(e => handleError("Failed to send tool response to Live API", e));
                      } else {
                        handleError("Cannot send tool response: sessionPromiseRef is null");
                      }
                    } catch (error) {
                      handleError("A2A Tool Call Execution Failed", error);
                      
                      setChatHistory(prev => [...prev, {
                        id: `system-${Date.now()}-error`,
                        role: 'system',
                        text: `Failed to retrieve account details.`,
                        isFinal: true
                      }]);

                      if (sessionPromiseRef.current) {
                        sessionPromiseRef.current.then((session) => {
                          const errorPayload = {
                            functionResponses: [{
                              id: fc.id,
                              name: fc.name,
                              response: { error: "Failed to retrieve account details from A2A agent." }
                            }]
                          };
                          console.info('[Live API] 📤 Sending tool error payload:', JSON.stringify(errorPayload, null, 2));
                          session.sendToolResponse(errorPayload);
                        }).catch(e => handleError("Failed to send tool error response to Live API", e));
                      }
                    }
                  })();
                } else {
                  console.warn(`[Live API] ⚠️ Received unknown tool call: ${fc.name}`);
                  handleError(`Model requested unknown tool call: ${fc.name}`);
                }
              }
            }

            if (message.serverContent?.outputTranscription) {
              // Mark agent as talking on the first output transcription chunk of a turn
              if (currentOutputTextRef.current === '') {
                setAgentTalking(true);
              }
              currentOutputTextRef.current += message.serverContent.outputTranscription.text;
              setLiveOutput(currentOutputTextRef.current);
            }

            if (message.serverContent?.inputTranscription) {
              currentInputTextRef.current += message.serverContent.inputTranscription.text;
              setLiveInput(currentInputTextRef.current);
            }

            const flushTranscriptions = () => {
              const inputText = currentInputTextRef.current.trim();
              const outputText = currentOutputTextRef.current.trim();

              if (inputText || outputText) {
                setChatHistory(prev => {
                  const newHistory = [...prev];
                  if (inputText) {
                    newHistory.push({
                      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                      role: 'user',
                      text: inputText,
                      isFinal: true
                    });
                  }
                  if (outputText) {
                    newHistory.push({
                      id: `model-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                      role: 'model',
                      text: outputText,
                      isFinal: true
                    });
                  }
                  return newHistory;
                });

                if (inputText) {
                  currentInputTextRef.current = '';
                  setLiveInput('');
                }
                if (outputText) {
                  currentOutputTextRef.current = '';
                  setLiveOutput('');
                }
              }
            };

            if (message.serverContent?.interrupted || message.serverContent?.turnComplete) {
              flushTranscriptions();
              setAgentTalking(false);
            }

            const parts = message.serverContent?.modelTurn?.parts;
            if (parts) {
              for (const part of parts) {
                if (part.inlineData) {
                  const mimeType = part.inlineData.mimeType;
                  const base64Data = part.inlineData.data;

                  if (mimeType.startsWith('video/mp4')) {
                    if (userHasSpokenForNextTurnRef.current) {
                      trackingAvatarAudioRef.current = true;
                      userHasSpokenForNextTurnRef.current = false;
                      avatarAudioStartPlayheadRef.current = null;
                      avatarAudioStartPlayheadSystemTimeRef.current = null;
                    }

                    setHasVideo(true);
                    setIsWaitingForVideo(false);
                    initMediaSource();

                    const uint8Array = decode(base64Data);
                    const arrayBuffer = uint8Array.buffer.slice(uint8Array.byteOffset, uint8Array.byteOffset + uint8Array.byteLength);

                    if (!cachedInitSegmentRef.current) {
                      cachedInitSegmentRef.current = arrayBuffer;
                    }

                    const sourceBuffer = sourceBufferRef.current;
                    if (sourceBuffer && !sourceBuffer.updating && videoQueueRef.current.length === 0) {
                      try {
                        sourceBuffer.appendBuffer(arrayBuffer);
                      } catch (e: any) {
                        if (e.name === "InvalidStateError") {
                          mseRef.current = null;
                          sourceBufferRef.current = null;
                          videoQueueRef.current = [];
                          handleError("MediaSource Invalid State", e);
                        } else {
                          videoQueueRef.current.push(arrayBuffer);
                        }
                      }
                    } else {
                      videoQueueRef.current.push(arrayBuffer);
                    }
                  }
                }
              }
            }
          },
          onerror: (e: ErrorEvent) => {
            handleError('A connection error occurred in Live API.', e);
            disconnect();
          },
          onclose: (e: CloseEvent) => {
            console.info('[Live API] 🔌 Connection closed.', e);
            disconnect();
          },
        },
        config: liveConfig,
      });

      sessionPromiseRef.current = sessionPromise;
    } catch (err) {
      handleError('Failed to initialize connection.', err);
      disconnect();
    }
  }, [isConnected, isConnecting, disconnect, initMediaSource, monitoringLoop, isMuted, handleError]);

  const switchMicrophone = useCallback(async (deviceId: string) => {
    if (isConnected && streamRef.current) {
      try {
        console.info(`[Live API] Switching microphone to device: ${deviceId}`);
        const newStream = await navigator.mediaDevices.getUserMedia({
          audio: deviceId ? { deviceId: { exact: deviceId } } : true
        });

        newStream.getAudioTracks().forEach(track => track.enabled = !isMuted);

        if (mediaSourceRef.current) {
          mediaSourceRef.current.disconnect();
        }
        streamRef.current.getTracks().forEach(track => track.stop());

        if (inputAudioContextRef.current && scriptProcessorRef.current) {
          const newSource = inputAudioContextRef.current.createMediaStreamSource(newStream);
          newSource.connect(scriptProcessorRef.current);
          mediaSourceRef.current = newSource;
        }
        streamRef.current = newStream;
        console.info('[Live API] Microphone switched successfully.');
      } catch (err) {
        handleError("Failed to switch microphone.", err);
      }
    }
  }, [isConnected, isMuted, handleError]);

  const sendTextMessage = useCallback((text: string) => {
    if (!text.trim() || !sessionPromiseRef.current || !isSetupCompleteRef.current) return;

    console.info(`[Live API] 💬 Sending text message: "${text}"`);
    sessionPromiseRef.current.then((session) => {
      try {
        session.sendRealtimeInput({ text });

        // Add to chat history immediately for better UX
        setChatHistory(prev => [
          ...prev,
          {
            id: `user-text-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            role: 'user',
            text: text.trim(),
            isFinal: true
          }
        ]);
      } catch (e) {
        handleError("Failed to send text message", e);
      }
    }).catch(e => handleError("Promise rejection sending text message", e));
  }, [handleError]);

  return {
    isConnected,
    isConnecting,
    isSetupComplete,
    isWaitingForVideo,
    hasVideo,
    error,
    sessionErrors,
    chatHistory,
    liveInput,
    liveOutput,
    debugStats,
    videoRef,
    connect,
    disconnect,
    switchMicrophone,
    sendTextMessage
  };
};

