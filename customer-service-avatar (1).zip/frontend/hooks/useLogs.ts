import { useState, useEffect, useCallback } from 'react';
import { LogEntry } from '../types';

const safeStringify = (obj: any) => {
  if (typeof obj === 'string') return obj;
  if (obj instanceof Error) {
    return `${obj.name}: ${obj.message}\n${obj.stack}`;
  }
  if (typeof obj === 'object' && obj !== null) {
    try {
      const cache = new Set();
      return JSON.stringify(obj, (key, value) => {
        if (typeof value === 'object' && value !== null) {
          if (cache.has(value)) {
            return '[Circular Reference]';
          }
          cache.add(value);
        }
        return value;
      }, 2);
    } catch (e) {
      return Object.prototype.toString.call(obj);
    }
  }
  return String(obj);
};

export const useLogs = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);

  useEffect(() => {
    const originalConsole = {
      log: console.log,
      error: console.error,
      warn: console.warn,
      info: console.info,
      debug: console.debug,
    };

    const createLogEntry = (level: LogEntry['level'], args: any[]) => {
      const message = args.map(safeStringify).join(' ');
      setLogs(prev => [...prev, {
        id: Math.random().toString(36).substring(2, 9) + Date.now(),
        timestamp: new Date(),
        level,
        message,
      }]);
    };

    console.log = (...args) => { originalConsole.log(...args); createLogEntry('log', args); };
    console.error = (...args) => { originalConsole.error(...args); createLogEntry('error', args); };
    console.warn = (...args) => { originalConsole.warn(...args); createLogEntry('warn', args); };
    console.info = (...args) => { originalConsole.info(...args); createLogEntry('info', args); };
    console.debug = (...args) => { originalConsole.debug(...args); createLogEntry('debug', args); };

    return () => {
      console.log = originalConsole.log;
      console.error = originalConsole.error;
      console.warn = originalConsole.warn;
      console.info = originalConsole.info;
      console.debug = originalConsole.debug;
    };
  }, []);

  const clearLogs = useCallback(() => setLogs([]), []);

  return { logs, clearLogs };
};