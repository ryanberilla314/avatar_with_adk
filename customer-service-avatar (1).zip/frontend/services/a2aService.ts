const AGENT_ID = 'projects/419844573156/locations/us-central1/reasoningEngines/6766173005740507136';
const LOCATION = 'us-central1';
const BASE_URL = `https://${LOCATION}-aiplatform.googleapis.com/v1/${AGENT_ID}`;

export const createA2ASession = async (userId: string): Promise<string> => {
  const payload = {
    classMethod: 'async_create_session',
    input: { user_id: userId }
  };
  
  console.info(`[A2A Service] 🚀 Initiating createA2ASession for user: ${userId}`);
  console.debug(`[A2A Service] POST ${BASE_URL}:query`);
  console.debug(`[A2A Service] Request Payload:`, JSON.stringify(payload, null, 2));

  try {
    const token = process.env.REACT_APP_GCP_ACCESS_TOKEN || process.env.GCP_ACCESS_TOKEN;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${BASE_URL}:query`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    });

    console.info(`[A2A Service] 📥 createA2ASession Response Status: ${response.status} ${response.statusText}`);

    if (!response.ok) {
      const errText = await response.text().catch(() => 'Unable to read error body');
      console.error(`[A2A Service] ❌ Error Response Body:`, errText);
      throw new Error(`HTTP ${response.status} ${response.statusText} - ${errText}`);
    }

    const data = await response.json();
    console.debug(`[A2A Service] Parsed Response Data:`, JSON.stringify(data, null, 2));
    
    if (!data?.output?.id) {
      throw new Error(`Invalid response format: Missing output.id in ${JSON.stringify(data)}`);
    }
    
    console.info(`[A2A Service] ✅ Successfully created A2A session: ${data.output.id}`);
    return data.output.id;
  } catch (error) {
    console.error(`[A2A Service] 💥 Exception in createA2ASession:`, error);
    throw error;
  }
};

export const queryA2AAgent = async (userId: string, sessionId: string, message: string): Promise<string> => {
  const payload = {
    classMethod: 'async_stream_query',
    input: {
      user_id: userId,
      session_id: sessionId,
      message: message
    }
  };

  console.info(`[A2A Service] 🚀 Initiating queryA2AAgent for session: ${sessionId}`);
  console.debug(`[A2A Service] POST ${BASE_URL}:streamQuery`);
  console.debug(`[A2A Service] Request Payload:`, JSON.stringify(payload, null, 2));

  try {
    const token = process.env.REACT_APP_GCP_ACCESS_TOKEN || process.env.GCP_ACCESS_TOKEN;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${BASE_URL}:streamQuery`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    });

    console.info(`[A2A Service] 📥 queryA2AAgent Response Status: ${response.status} ${response.statusText}`);

    if (!response.ok) {
      const errText = await response.text().catch(() => 'Unable to read error body');
      console.error(`[A2A Service] ❌ Error Response Body:`, errText);
      throw new Error(`HTTP ${response.status} ${response.statusText} - ${errText}`);
    }

    if (!response.body) {
      console.error(`[A2A Service] ❌ Response body is null`);
      throw new Error('No response body from A2A agent');
    }

    const decoder = new TextDecoder();
    let fullResponse = '';

    console.info(`[A2A Service] 📖 Starting to read stream...`);
    for await (const chunk of response.body as any) {
      const chunkText = decoder.decode(chunk, { stream: true });
      console.debug(`[A2A Service] Raw Stream Chunk Received:\n${chunkText}`);
      
      try {
        // Handle potential multiple JSON objects in a single chunk separated by newlines
        const lines = chunkText.split('\n').filter((l: string) => l.trim() !== '');
        for (const line of lines) {
          const parsed = JSON.parse(line);
          if (parsed.content && parsed.content.parts && parsed.content.parts.length > 0) {
            const textPart = parsed.content.parts[0].text;
            if (textPart) {
              fullResponse += textPart;
            }
          }
        }
      } catch (e) {
        console.warn("[A2A Service] ⚠️ Error parsing A2A stream chunk (might be incomplete JSON):", e, chunkText);
      }
    }

    console.info(`[A2A Service] ✅ Stream complete. Full Response length: ${fullResponse.length} chars`);
    console.debug(`[A2A Service] Full Response Content:`, fullResponse);
    return fullResponse;
  } catch (error) {
    console.error(`[A2A Service] 💥 Exception in queryA2AAgent:`, error);
    throw error;
  }
};