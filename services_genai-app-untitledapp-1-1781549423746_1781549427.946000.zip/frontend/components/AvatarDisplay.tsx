import React, { useState } from 'react';
import { liveServiceConfiguration } from '../resources/live_service_configuration';

interface Props {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  hasVideo: boolean;
  isConnected: boolean;
  isLoading: boolean;
  error: string | null;
}

export const AvatarDisplay: React.FC<Props> = ({ videoRef, hasVideo, isConnected, isLoading, error }) => {
  const [aspectRatio, setAspectRatio] = useState<number>(1);

  const avatarData = (liveServiceConfiguration as any).avatarConfig?.customizedAvatar?.imageData || '';
  const avatarMime = (liveServiceConfiguration as any).avatarConfig?.customizedAvatar?.imageMimeType || 'image/png';
  const avatarName = (liveServiceConfiguration as any).avatarConfig?.avatarName || '';

  let avatarSrc = '';
  if (avatarData) {
    avatarSrc = `data:${avatarMime};base64,${avatarData}`;
  } else if (avatarName) {
    avatarSrc = `https://www.gstatic.com/pantheon/images/aiplatform/vertex_ai_studio/avatars/${avatarName.toLowerCase()}.png`;
  }

  return (
    <div className={`relative transition-all duration-500 rounded-3xl overflow-hidden flex-shrink-0 bg-gray-50 dark:bg-gray-950 ${isConnected ? 'shadow-[0_0_40px_rgba(34,197,94,0.2)]' : 'shadow-lg'}`}
      style={{
        width: '100%',
        maxWidth: `min(85vw, 70%, 80vh * ${aspectRatio})`,
        aspectRatio: aspectRatio
      }}>

      <video
        ref={videoRef as React.RefObject<HTMLVideoElement>}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${hasVideo ? 'opacity-100' : 'opacity-0'}`}
        playsInline
        autoPlay
      />

      <img
        src={avatarSrc}
        alt="AI Avatar"
        onLoad={(e) => {
          const { naturalWidth, naturalHeight } = e.currentTarget;
          if (naturalWidth && naturalHeight) {
            setAspectRatio(naturalWidth / naturalHeight);
          }
        }}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${hasVideo ? 'opacity-0' : 'opacity-100'}`}
      />

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2.5 bg-black/60 backdrop-blur-md px-4 py-2 rounded-full shadow-sm z-50 pointer-events-none">
        <div className={`w-2.5 h-2.5 rounded-full ${error ? 'bg-red-500' :
            isLoading ? 'bg-yellow-500 animate-pulse shadow-[0_0_8px_rgba(234,179,8,0.8)]' :
              isConnected ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]' :
                'bg-gray-400'
          }`}></div>
        <span className="text-sm font-medium text-white whitespace-nowrap">
          {error ? <span className="text-red-400">{error}</span> :
            isLoading ? 'Connecting...' :
              isConnected ? 'Connected' : 'Ready to connect'}
        </span>
      </div>
    </div>
  );
};
